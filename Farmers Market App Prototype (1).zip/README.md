
  # Farmers Market App Prototype

  This is a code bundle for Farmers Market App Prototype. The original project is available at https://www.figma.com/design/oaSTvS0XvBZUjJ34SiMMxj/Farmers-Market-App-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  